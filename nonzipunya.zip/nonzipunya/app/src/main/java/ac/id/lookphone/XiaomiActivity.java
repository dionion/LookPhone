package ac.id.lookphone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class XiaomiActivity extends AppCompatActivity {
    private PDFView pdfView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xiaomi);
        pdfView = findViewById(R.id.pdfView);
        pdfView.fromAsset("XIAOM MI 8pro.pdf")
                .enableSwipe(true)
                .load();
    }
}
